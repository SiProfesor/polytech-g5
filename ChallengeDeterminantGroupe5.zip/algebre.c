#include "algebre.h"
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

mymatrix * creer (int n, int m)
{
  int i, j ;
  mymatrix * tmp = malloc(sizeof(mymatrix)) ;
  tmp->n = n ;
  tmp->m = m ;
  // allocation de la matrice
  tmp->M = malloc(n*sizeof(float *)) ;
  for (i=0; i<n; i++)
    (tmp->M)[i] = malloc(m*sizeof(float)) ;
  // initialisation à 0
  for (i=0; i<n; i++)
  {
    for (j=0; j<m; j++)
      (tmp->M)[i][j] = 0 ;
  }
  return tmp ;
}


mymatrix * concatener (mymatrix *A, mymatrix *B)
{
  mymatrix *C ;
  int i, j, k ;
  assert(A->n == B->n) ;
  C = creer(A->n, A->m+B->m) ;
  for (i=0; i < A->n; i++)
  {
    k = 0 ;
    for (j=0; j < A->m;  j++,k++)
      (C->M)[i][k] = (A->M)[i][j] ;
    for (j=0; j < B->m;  j++,k++)
      (C->M)[i][k] = (B->M)[i][j] ;
  }
  return C ;
}

void print_matrix(mymatrix *A)
{
  int i, j ;

  for (i=0; i<A->n; i++)
  {
    for (j=0; j<A->m; j++)
      printf("%f\t", (A->M)[i][j]) ;
    printf("\n") ;
  }
}


int gauss (mymatrix *C, int n, int k) {

  int i = 0; //'i' désigne la ligne en cours de traitement
 
  while (i < n) {

    //printf("Traitement de la colonne %d...\n", i);

    //Trouve le maximum de la colonne i : ce sera notre pivot de Gauss
    int lignePivot = i;
    for (int rechercheMax = i; rechercheMax < n; rechercheMax++) {

      //Cas où la case vaut 0 : on ne peut pas la choisir comme pivot de Gauss
      if((C->M)[rechercheMax][i] == 0 && rechercheMax == lignePivot) {
        lignePivot++;
        continue;
      }

      //Si un max est trouvé, on le choisit
      if( (C->M)[rechercheMax][i] > (C->M)[lignePivot][i] && (C->M)[rechercheMax][i] != 0)
        lignePivot = rechercheMax;
    /* else if( (C->M)[rechercheMax][i] == (C->M)[lignePivot][i] ) //Sinon si la case est égale
        lignePivot++;*/
    }

    //Colonne de 0 => pas besoin de faire le pivot de Gauss
    if(lignePivot >= n) {
      i++;
      //printf("Colonne de 0. Pas de pivot à faire.\n");
      return 0;
    }

    //printf("Maximum de C[%d][%d] %f\n", lignePivot, i, (C->M)[lignePivot][i]);

    int l = 0, c = 0; //'l' et 'c' désignent la ligne et la colonne qui subissent la combinaison linéaire

    l = 0;
    //On fait les combinaisons linéaires sur chaque ligne
    while (l < n) {

      //On fait sur toutes les lignes sauf celle qui sert de pivot
      if(l != lignePivot) {

        double lambda = -((C->M)[l][i]) / ((C->M)[lignePivot][i]); //La valeur de la combinaison linéaire

        //L(l) <- L(l) + lambda * L(lignePivot)
        //printf("l%d <- l%d + %f * l%d\n", l, l, lambda, lignePivot );
        
        //On itère sur toutes les colonnes
        for(c = 0; c < n + k; c++) {

          (C->M)[l][c] += lambda * (C->M)[lignePivot][c];
        }
      }

      l++;
    }

    //On inverse la ligne de Pivot avec la i-ème ligne pour l'exclure de la recherche du max plus facilement
    for(c = 0; c < n + k; c++) {
      float tmp = (C->M)[i][c];
      (C->M)[i][c] = (C->M)[lignePivot][c];
      (C->M)[lignePivot][c] = tmp;
    }

    //print_matrix(C);

    i++;
  }

  //Le matrice est inversible si et seulement si l'une des cases sur la diagonale est nulle
  i = 0;
  while (i < n && (C->M)[i][i] != 0)
    i++;

  return i >= n;
}

int remontee_gauss (mymatrix *C, int n, int k) {

  //On part de la dernière ligne, vers la première
  int i = n - 1;

  while (i >= 0) {

    //On fait en sorte que le coefficient de la ligne soit égal à 1
    int c = i;
    double lambda = 1 / (C->M)[c][c]; //La quantité à multiplier pour avoir 1 sur la case (c,c)
    
    //L(l) <- lambda * L(l)
    //printf("l%d <- %f * l%d\n", i, lambda, i );

    while (c < n + k) {
      (C->M)[i][c] *= lambda;
      c++;
    }

    //Les lignes de 0 à i - 1 sont combinées à la ligne i pour avoir des 0 dans les colonnes qui correspondent
    int j = 0;
    while (j < i) {

      double lambda2 = -( (C->M)[j][c] ); //La valeur de la combinaison linéaire
      
      //L(j) <- L(j) + lambda * L(i)
      //printf("l%d <- l%d + %f * l%d\n", j, j, lambda2, i );
    
      //Application sur toutes les colonnes
      c = 0;
      while (c < n + k) {
        (C->M)[j][c] += lambda2 * (C->M)[i][c];
        c++;
      }

      j++;
    }

    i--; //Passe à la ligne précédente (on fait bien une remontée)
  }

  //print_matrix(C);
  return 1;
}

int inverserMatrice (mymatrix *A) {
  //Inverse la matrice A

  int n = A->n; //Taille de la matrice A carrée

  //Génère la matrice identité de taille n*n dans 'R'
  mymatrix *ID = creer(n, n);
  for (int i = 0; i < n; i++)
    (ID->M)[i][i] = 1;

  mymatrix *C = concatener(A, ID); //On donne la matrice C étant le jointure de A et R

  //Si le calcul de avec Gauss échoue, la matrice n'est pas inversible
  if(gauss(C, n, n) == 0)
    return 0;

  //Si correct, on retrouve dans C la matrice R à la place de A et A-1 à la place de R
  remontee_gauss(C, n, n);
  
  //Place dans A la nouvelle matrice inversée A-1
   for (int i = 0; i < n; i++)
     for (int j = 0; j < n; j++)
      (A->M)[i][j] = (C->M)[i][j + n];

  return 1;
}

float detMatrice (mymatrix *A) {
  //Calcule et retourne le déterminant de la matrice A

  //On rend la matrice triangulaire selon Gauss
  //Si la matrice n'est pas inversible, alors on retourne 0 (même si ça ne devrait pas)
  if(gauss(A, A->n, 0) == 0)
    return 0;

  //Sinon on doit retourner le produit des cases à la diagonale
  float res = 1;
  for(int i = 0; i < A->n; i++)
    res *= (A->M)[i][i];

  return res;
}

mymatrix *solveMatrice (mymatrix *Coeffs, mymatrix *Results) {

  //Usage : le système d'équation d'écrit sous la forme Coeffs * X = Results où X est le vecteur contenant les inconnues à trouver
  mymatrix *C = concatener(Coeffs, Results);

  //Si la matrice n'est pas inversible, alors le système n'a pas de solutions
  if(gauss(C, Coeffs->n, 1) == 0)
    return NULL;

  remontee_gauss(C, Coeffs->n, 1);

  //Inscription des résultats dans Results
  /*for(int i = 0; i < Coeffs->n; i++) {
    (Results->M)[i][0] = (C->M)[i][Coeffs->n];
  }*/

  return C;
}