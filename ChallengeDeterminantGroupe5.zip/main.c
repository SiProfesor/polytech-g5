#include <stdio.h>
#include "algebre.h"

mymatrix *SaisieMatrice (int n, int m) {

  //L'utilisateur entre une matrice en spécifiant sa taille (si n = 0) ou avec une taille définie à l'avance (n != 0)

  //Si la taille de la matrice n'est pas spécifiée, l'utilisateur la choisit avant
  if(n <= 0) {
    printf("Entrer la taille de la matrice associée : ");
    scanf("%d", &n);

    m = n; //Saisie manuelle de la taille de la matrice => matrice carrée
  }

  mymatrix *A = creer(n,m) ;

  //Entrée des coefficients
  float temp;
  for (int i = 0; i < n; i++){
    for (int j = 0; j < m ; j++){
      printf("Entrer le %d-ième cofficient de la %d-ième ligne : ", j+1, i+1);
      scanf("%f", &temp);
      (A->M)[i][j] = temp;
    }
  }

  return A;
}

int main()
{
  int choix = 1;

  while(choix > 0 && choix < 4){

    //--------------- Menu principal ---------------
    printf("\n ---------------MENU--------------- \n\n");
    printf("1 - Resoudre un système linéaire\n2 - Inverser une matrice\n3 - Calculer un determinant\n0 - Sortir\n\n");
    printf("Votre choix : ");
    scanf("%d", &choix); //Saisie du choix par l'utilisateur

    //Actions différentes en fonction du choix
    switch (choix){

      //--------------- Système linéaire ---------------
      case 1 :
        printf("\n---------------SYSTEME LINÉAIRE--------------- \n\n");

        //Saisie des coefficients du système linéaire
        printf("[Étape 1 / 2] Saisie des coefficients du système\n");
        mymatrix *A = SaisieMatrice(0, 0);

        //Saisie des résultats du système
        printf("[Étape 2 / 2] Saisie des résultats du système\n");
        mymatrix *B = SaisieMatrice(A->n, 1);

        //Résolution et affichage
        mymatrix *resultat = solveMatrice(A, B);
      
        if(resultat == NULL) {
          printf("\nLe système saisi n'a pas de solution.\n");
        }
        else {
          printf("\nSystème résolu : \n\n"); 
          print_matrix(resultat);
          printf("\n");
        }

        break;

      //--------------- INVERSION DE MATRICE ---------------
      case 2 :

        //Saisie
        printf("\n---------------MATRICE INVERSE--------------- \n\n");
        mymatrix *D = SaisieMatrice(0, 0);

        //Affichage
        printf("\nMatrice originale : \n\n");
        print_matrix(D);

        if(inverserMatrice(D) == 0) {
          printf("\nCette matrice n'est pas inversible.\n");
        }
        else {
          printf("\nMatrice inverse : \n\n");
          print_matrix(D) ;
        }
        break;

      //--------------- DÉTERMINANT ---------------
      case 3 : 

        //Saisie
        printf("\n---------------DÉTERMINANT--------------- \n\n");
        mymatrix *E = SaisieMatrice(0, 0);

        //Résultat
        printf("\nMatrice : \n\n");
        print_matrix(E) ;
        printf("\nDéterminant : %f\n", detMatrice(E));
        break;
    }
  }
  
  return 0 ;
}
